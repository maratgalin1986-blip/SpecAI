// Автотесты Telegram-помощника: имитация Telegram Bot API, Workers AI и базы D1 (node:sqlite).
import { DatabaseSync } from "node:sqlite";
import { readFileSync, writeFileSync } from "node:fs";
import assert from "node:assert/strict";

const src = readFileSync(new URL("./worker.js", import.meta.url), "utf8");
writeFileSync(new URL("./.worker_test.mjs", import.meta.url), src + "\nexport { Db, matchMachine, estimate, normPhone, findPhone, parseAi, clean, leadSig };\n");
const W = await import("./.worker_test.mjs?" + Date.now());
const worker = W.default;

/* ---------- D1 на node:sqlite ---------- */
class Stmt {
  constructor(db, sql, args) { this.db = db; this.sql = sql; this.args = args || []; }
  bind(...a) {
    for (const v of a) if (v === undefined) throw new Error("D1_TYPE_ERROR: undefined in bind: " + this.sql);
    return new Stmt(this.db, this.sql, a.map((v) => (typeof v === "boolean" ? (v ? 1 : 0) : v)));
  }
  async run() { const r = this.db.prepare(this.sql).run(...this.args); return { success: true, meta: { changes: Number(r.changes), last_row_id: Number(r.lastInsertRowid) } }; }
  async first() { return this.db.prepare(this.sql).get(...this.args) ?? null; }
  async all() { return { results: this.db.prepare(this.sql).all(...this.args) }; }
}
class D1 { constructor() { this.db = new DatabaseSync(":memory:"); } prepare(sql) { return new Stmt(this.db, sql); } }

/* ---------- Telegram ---------- */
const OWNER = 5550001, ADMIN = OWNER, CLIENT = 7770001, CLIENT2 = 7770002, BOT_ID = 999;
let calls = [], msgId = 100, bizOwner = OWNER;
globalThis.fetch = async (url, init) => {
  url = String(url);
  if (url.includes("/file/bot")) return new Response(new Uint8Array([79, 103, 103, 83, 1, 2, 3, 4]));
  const method = url.split("/").pop();
  let body = {};
  if (init && init.body instanceof FormData) body = Object.fromEntries(init.body.entries());
  else if (init && init.body) body = JSON.parse(init.body);
  calls.push({ method, body });
  const ok = (result) => new Response(JSON.stringify({ ok: true, result }));
  if (method === "getMe") return ok({ id: BOT_ID, username: "SpecTehII247_bot", can_connect_to_business: true });
  if (method === "sendMessage" || method === "sendDocument") return ok({ message_id: ++msgId });
  if (method === "getFile") return ok({ file_path: "voice/file_1.oga" });
  if (method === "getBusinessConnection") return ok({ id: body.business_connection_id, user: { id: bizOwner, first_name: "Кто-то" }, user_chat_id: bizOwner, is_enabled: true, rights: { can_reply: true } });
  return ok(true);
};

/* ---------- Workers AI ---------- */
let aiCalls = [], aiScript = [], aiFail = 0, jsonModeFail = 0, aiHook = null;
const AI = {
  async run(model, input) {
    aiCalls.push({ model, input });
    if (model.includes("whisper")) { assert.equal(typeof input.audio, "string"); return { text: "Нужен кран на 25 тонн в Нижнекамск послезавтра" }; }
    if (aiHook) { const h = aiHook; aiHook = null; await h(); }
    if (aiFail > 0) { aiFail--; throw new Error("3036: Account limited: you have used up your daily free allocation of 10,000 neurons"); }
    if (jsonModeFail > 0 && input.response_format) { jsonModeFail--; throw new Error("JSON Mode couldn't be met"); }
    const next = aiScript.shift();
    if (!next) return { response: { reply: "Уточните, пожалуйста, задачу.", handoff: false } };
    return { response: next };
  },
};

const env = { BOT_TOKEN: "123456:TEST-token", SETUP_KEY: "очень-длинный-ключ-2026", AI, DB: new D1(), DEBOUNCE_MS: 0 };
const ORIGIN = "https://spectehii-bot.test.workers.dev";
let secret, uid = 1;
async function hook(update, hdr) {
  const pending = [];
  const req = new Request(ORIGIN + "/tg", { method: "POST", headers: { "content-type": "application/json", "x-telegram-bot-api-secret-token": hdr === undefined ? secret : hdr }, body: JSON.stringify(Object.assign({ update_id: uid++ }, update)) });
  const res = await worker.fetch(req, env, { waitUntil: (p) => pending.push(p) });
  await Promise.all(pending);
  return res;
}
const msg = (from, text, extra) => ({ message: Object.assign({ message_id: uid, date: Math.floor(Date.now() / 1000), chat: { id: from.id, type: "private" }, from, text }, extra || {}) });
const sent = (pred) => calls.filter((c) => c.method === "sendMessage" && (!pred || pred(c.body)));
const lastTo = (chatId) => sent((b) => b.chat_id === chatId).pop();
const reset = () => { calls = []; aiCalls = []; };
const sql = (q, ...a) => env.DB.db.prepare(q).run(...a);
const U = { id: CLIENT, first_name: "Иван", last_name: "<b>Петров</b>", username: "ivan_stroy" };
const A = { id: ADMIN, first_name: "Марат", username: "Specplast16" };
let pass = 0; const ok = (name) => { pass++; console.log("  ✔ " + name); };

/* ================= тесты ================= */
console.log("Настройка");
let r = await worker.fetch(new Request(ORIGIN + "/setup?key=wrong"), env, {});
assert.equal(r.status, 403); ok("/setup с неверным ключом — 403");
r = await worker.fetch(new Request(ORIGIN + "/setup?key=" + encodeURIComponent(env.SETUP_KEY)), env, {});
let page = await r.text();
assert.equal(r.status, 200); assert.match(page, /Бот: @SpecTehII247_bot, бизнес-режим включён/); assert.match(page, /\/admin /);
const wh = calls.find((c) => c.method === "setWebhook").body;
secret = wh.secret_token;
assert.equal(wh.url, ORIGIN + "/tg"); assert.match(secret, /^[0-9a-f]{48}$/); assert.deepEqual(wh.allowed_updates, ["message", "callback_query", "business_connection", "business_message"]);
ok("/setup: таблицы, вебхук с секретом, описание бота");
r = await worker.fetch(new Request(ORIGIN + "/setup?key=x"), Object.assign({}, env, { SETUP_KEY: "short" }), {});
assert.equal(r.status, 400); ok("короткий SETUP_KEY не принимается");
r = await hook(msg(U, "привет"), "wrong");
assert.equal(r.status, 403); ok("вебхук без секрета — 403");
r = await worker.fetch(new Request(ORIGIN + "/privacy"), env, {}); assert.match(await r.text(), /Cloudflare/); ok("страница обработки данных /privacy");

console.log("Администратор");
reset(); await hook(msg(A, "/admin неверный-ключ-123456"));
assert.match(lastTo(ADMIN).body.text, /Неверный ключ/); ok("неверный /admin отклонён");
reset(); await hook(msg(A, "/admin " + env.SETUP_KEY));
assert.match(lastTo(ADMIN).body.text, /вы администратор/);
assert.ok(calls.find((c) => c.method === "setMyCommands" && c.body.scope && c.body.scope.chat_id === ADMIN)); ok("/admin с ключом — назначен, команды для владельца");
const THIEF = { id: 6660001, first_name: "Чужой", username: "thief" };
reset(); await hook(msg(THIEF, "/admin " + env.SETUP_KEY));
assert.match(lastTo(THIEF.id).body.text, /уже назначен/); assert.match(lastTo(ADMIN).body.text, /пытался стать администратором.*@thief/);
assert.equal(Number((await env.DB.prepare("SELECT v FROM kv WHERE k='admin_id'").first()).v), ADMIN); ok("второй человек с ключом админом не станет, владелец предупреждён");

console.log("Клиент пишет боту");
reset(); await hook(msg(U, "/start"));
assert.match(lastTo(CLIENT).body.text, /ИИ-помощник СпецТехИИ 24\/7/); assert.ok(lastTo(CLIENT).body.reply_markup.inline_keyboard); ok("/start — приветствие и кнопки");
reset();
aiScript.push({ reply: "Здравствуйте! Автовышка на завтра, 27.09, фасад 18 м — подойдёт.\nВо сколько подать и на сколько часов? И оставьте, пожалуйста, телефон.", machine: "Автовышка (АГП)", city: "Набережные Челны", address: "пр. Мира, 52", date: "27.09.2026", task: "фасад, высота 18 м", time: "", hours: "не указано", phone: "", name: "", company: "", qty: "", handoff: false });
await hook(msg(U, "Нужна автовышка завтра на Мира 52 в Челнах, фасад 18 метров"));
let ans = lastTo(CLIENT).body;
assert.match(ans.text, /подойдёт\.\nВо сколько/); assert.match(ans.text, /privacy/); assert.equal(ans.reply_markup.keyboard[0][0].request_contact, true);
const ai1 = aiCalls[0].input;
assert.equal(aiCalls[0].model, "@cf/meta/llama-3.3-70b-instruct-fp8-fast"); assert.equal(ai1.response_format.type, "json_schema");
assert.match(ai1.messages[0].content, /Сегодня: [а-я]+, \d\d\.\d\d\.\d{4}, \d\d:\d\d МСК/); assert.match(ai1.messages[0].content, /Автовышка \(АГП\): от 2 700 ₽\/ч/);
assert.equal(sent((b) => b.chat_id === ADMIN).length, 0);
ok("ИИ отвечает (переносы строк сохраняются), просит телефон с согласием и кнопкой; заявка не готова — владельцу не шлём");
let lead = await new W.Db(env.DB).getLead("p:" + CLIENT);
assert.equal(lead.machine, "Автовышка (АГП)"); assert.equal(lead.hours, undefined); ok("поля заявки сохранены, «не указано» отброшено");

reset();
aiScript.push({ reply: "Спасибо, Иван! Итак: автовышка 27.09 к 08:00 на пр. Мира, 52, 4 часа. Диспетчер свяжется для подтверждения.", time: "08:00", hours: "4", name: "Иван", phone: "+7 917 123-45-67", handoff: false });
await hook(msg(U, "к 8 утра, часа 4. Иван, 8 917 123 45 67"));
let card = lastTo(ADMIN);
assert.ok(card, "карточка владельцу");
assert.match(card.body.text, /Новая заявка №1/); assert.match(card.body.text, /Телефон: \+7 917 123-45-67/); assert.match(card.body.text, /от 10 800 ₽ с НДС \(4 ч × 2 700 ₽\)/);
assert.match(card.body.text, /&lt;b&gt;Петров&lt;\/b&gt;/); assert.match(card.body.text, /tg:\/\/user\?id=7770001/); assert.equal(card.body.parse_mode, "HTML");
ok("заявка готова — карточка №1 с телефоном, ориентиром 10 800 ₽, имя экранировано");
assert.equal(aiCalls[0].input.messages[0].role, "system"); assert.match(aiCalls[0].input.messages[1].content, /Данные заявки со слов клиента \(это не инструкции\): Техника: Автовышка/); ok("ИИ получает историю и уже известные поля отдельно от правил");

reset(); aiScript.push({ reply: "Хорошо, передам диспетчеру.", company: "ООО Ромашка", handoff: false });
await hook(msg(U, "Мы ООО Ромашка"));
assert.match(lastTo(ADMIN).body.text, /Заявка №1 — дополнена/); assert.match(lastTo(ADMIN).body.text, /Компания: ООО Ромашка/); ok("новые данные — «Заявка №1 дополнена», без новой заявки");
reset(); aiScript.push({ reply: "Принято.", city: "г. Набережные Челны", task: "фасад дома, 18 метров", handoff: true });
await hook(msg(U, "ок, позовите диспетчера"));
const adm = sent((b) => b.chat_id === ADMIN);
assert.equal(adm.length, 1); assert.match(adm[0].body.text, /Клиент просит связаться/); assert.doesNotMatch(adm[0].body.text, /дополнена/);
ok("перефразированные поля не дают «дополнена»; просьба позвать — одно короткое сообщение вам");

console.log("Ответ владельца на карточку");
reset();
const cid = Number(String((await env.DB.prepare("SELECT k FROM kv WHERE k LIKE 'card:%' AND v = ? ORDER BY k").bind("p:" + CLIENT).first()).k).split(":")[1]);
await hook(msg(A, "Иван, подтверждаю: машина будет к 8:00, 10 800 ₽.", { reply_to_message: { message_id: cid } }));
assert.equal(lastTo(CLIENT).body.text, "Иван, подтверждаю: машина будет к 8:00, 10 800 ₽."); assert.match(lastTo(ADMIN).body.text, /Отправлено клиенту/);
reset(); await hook(msg(U, "А можно к 9:00?"));
assert.equal(aiCalls.length, 0); assert.equal(sent((b) => b.chat_id === CLIENT).length, 0); assert.match(lastTo(ADMIN).body.text, /Клиент ответил[\s\S]*А можно к 9:00\?/);
ok("ответ уходит клиенту; дальше ИИ молчит 12 ч, а сообщения клиента пересылаются вам");
reset(); await hook(msg(A, "", { reply_to_message: { message_id: cid }, voice: { file_id: "x" } }));
assert.match(lastTo(ADMIN).body.text, /только текст/); assert.equal(aiCalls.length, 0); ok("голосовой ответ на карточку не уходит в ИИ — просьба ответить текстом");

console.log("Телефон кнопкой, чужой контакт, геоточка");
const U2 = { id: CLIENT2, first_name: "Олег" };
reset(); await hook(msg(U2, "", { contact: { phone_number: "79001112233", user_id: 1234 } }));
assert.match(lastTo(CLIENT2).body.text, /свой номер/); assert.equal(aiCalls.length, 0); ok("чужая визитка не принимается");
reset(); aiScript.push({ reply: "Спасибо! Какая техника нужна?", handoff: false });
await hook(msg(U2, "", { contact: { phone_number: "79001112233", user_id: CLIENT2 } }));
assert.equal((await new W.Db(env.DB).getLead("p:" + CLIENT2)).phone, "+79001112233"); ok("свой номер кнопкой сохранён");
reset(); aiScript.push({ reply: "Вижу точку. Какой груз?", handoff: false });
await hook(msg(U2, undefined, { location: { latitude: 55.7255, longitude: 52.4112 } }));
assert.match((await new W.Db(env.DB).getLead("p:" + CLIENT2)).address, /yandex\.ru\/maps\/\?pt=52\.4112,55\.7255/); assert.match(aiCalls[0].input.messages.slice(-1)[0].content, /точку на карте/); ok("геоточка → адрес со ссылкой на Яндекс Карты");

console.log("Голосовое");
reset(); aiScript.push({ reply: "Автокран 25 т в Нижнекамск на 28.09 — какой вес груза и адрес?", machine: "Автокран", city: "Нижнекамск", date: "28.09.2026", handoff: false });
await hook(msg(U2, undefined, { voice: { file_id: "v1", duration: 5, file_size: 9000 } }));
assert.ok(aiCalls.find((c) => c.model.includes("whisper"))); assert.match(aiCalls.find((c) => !c.model.includes("whisper")).input.messages.slice(-1)[0].content, /^\(голосовое\) Нужен кран/);
assert.match(lastTo(ADMIN).body.text, /Новая заявка №2/); ok("голосовое → текст → ИИ → заявка №2");
reset(); await hook(msg(U2, undefined, { voice: { file_id: "v2", duration: 95, file_size: 90000 } }));
assert.match(lastTo(CLIENT2).body.text, /длиннее минуты/); assert.equal(aiCalls.length, 0); ok("голосовое длиннее минуты — просим текстом, ИИ не тратим");

console.log("Сбои ИИ");
const U3 = { id: 7770003, first_name: "Пётр" };
reset(); aiFail = 2;
await hook(msg(U3, "нужен самосвал"));
await hook(msg(U3, "песок 20 тонн"));
assert.equal(sent((b) => b.chat_id === 7770003).length, 1); assert.match(lastTo(7770003).body.text, /Передаю диспетчеру/);
assert.equal(sent((b) => b.chat_id === ADMIN && /ИИ временно недоступен/.test(b.text)).length, 2); ok("лимит ИИ исчерпан: клиенту один ответ, владельцу оба сообщения");
reset(); jsonModeFail = 1; aiScript.push('```json\n{"reply":"Откуда и куда везём песок?","machine":"Самосвал","handoff":false}\n```');
await hook(msg(U3, "самосвал нужен"));
assert.equal(aiCalls.length, 2); assert.equal(aiCalls[1].input.response_format, undefined); assert.equal(lastTo(7770003).body.text, "Откуда и куда везём песок?"); ok("JSON-режим не сработал — повтор без него, ответ разобран");
reset(); aiScript.push('{"reply": "Сколько кубов?", "machine": "Самосв');
await hook(msg(U3, "песок"));
assert.equal(lastTo(7770003).body.text, "Сколько кубов?"); ok("обрезанный JSON: клиенту только текст ответа");
reset(); aiScript.push('{"machine": "Самосвал", "city": "Нижне'); sql("UPDATE chats SET fallback_ts = NULL WHERE key = 'p:7770003'");
await hook(msg(U3, "щебень"));
assert.doesNotMatch(lastTo(7770003).body.text, /[{}"]/); assert.match(lastTo(7770003).body.text, /Передаю диспетчеру/); ok("мусор вместо ответа ИИ клиенту не уходит — срабатывает запасной путь");

console.log("Серия сообщений, флуд, повторы");
const U4 = { id: 7770004, first_name: "Анна" };
env.DEBOUNCE_MS = 60; reset();
aiScript.push({ reply: "Здравствуйте! Автокран на завтра в Челны — какой вес груза?", machine: "Автокран", city: "Набережные Челны", date: "27.09.2026", handoff: false });
await Promise.all(["Здравствуйте", "нужен кран", "на завтра, Челны"].map((t, i) => new Promise((res) => setTimeout(() => hook(msg(U4, t)).then(res), i * 10))));
assert.equal(aiCalls.length, 1); assert.equal(sent((b) => b.chat_id === 7770004).length, 1);
assert.deepEqual(aiCalls[0].input.messages.filter((x) => x.role === "user").map((x) => x.content), ["Здравствуйте", "нужен кран", "на завтра, Челны"]);
env.DEBOUNCE_MS = 0; ok("3 сообщения подряд — один ответ ИИ на все сразу");
sql("INSERT INTO chats (key, source, chat_id, user_id, lead, first_ts, last_ts) VALUES ('p:7770014','bot',7770014,7770014,?,?,?)", JSON.stringify({ machine: "Автовышка", city: "Челны", date: "30.09.2026", phone: "+79990001122" }), Date.now(), Date.now());
const dbx = new W.Db(env.DB), leadx = await dbx.getLead("p:7770014");
const claims = await Promise.all([1, 2, 3].map(() => dbx.claimSig("p:7770014", W.leadSig(leadx))));
assert.equal(claims.filter(Boolean).length, 1); ok("одновременная отправка одной заявки — пройдёт только одна");
reset(); aiScript.push({ reply: "Передаю диспетчеру, он свяжется.", handoff: true });
await hook(msg({ id: 7770024, first_name: "Анна" }, "Позовите человека"));
assert.match(lastTo(ADMIN).body.text, /Клиент просит связаться/); ok("просьба позвать человека — сразу владельцу");
const U5 = { id: 7770005, first_name: "Спам" };
reset(); for (let i = 0; i < 25; i++) await hook(msg(U5, "сообщение " + i));
assert.equal(aiCalls.length, 20); ok("флуд: из 25 сообщений за 10 минут обработано 20");
reset(); sql("UPDATE chats SET rl_ts = NULL, ai_n = 40 WHERE key = 'p:7770005'");
await hook(msg(U5, "ещё"));
assert.equal(aiCalls.length, 0); assert.match(lastTo(ADMIN).body.text, /ИИ больше не отвечает ему сегодня/); ok("больше 40 ответов ИИ одному клиенту в сутки — дальше пересылка вам");
reset(); const upd = Object.assign({ update_id: 99999 }, msg({ id: 7770025, first_name: "Дубль" }, "дубль"));
for (let i = 0; i < 2; i++) { const p = []; await worker.fetch(new Request(ORIGIN + "/tg", { method: "POST", headers: { "x-telegram-bot-api-secret-token": secret }, body: JSON.stringify(upd) }), env, { waitUntil: (x) => p.push(x) }); await Promise.all(p); }
assert.equal(aiCalls.length, 1); ok("повторная доставка одного события обрабатывается один раз");
reset(); await hook({ message: { message_id: 1, chat: { id: -100, type: "group" }, from: U, text: "нужен кран" } });
assert.equal(calls.length, 0); ok("сообщения из групп игнорируются");

console.log("Клиент вернулся через 3 дня");
sql("UPDATE chats SET last_ts = ?, paused_until = NULL WHERE key = ?", Date.now() - 4 * 864e5, "p:" + CLIENT);
reset(); aiScript.push({ reply: "Здравствуйте, Иван! Автокран — на какую дату и куда?", machine: "Автокран", handoff: false });
await hook(msg(U, "теперь нужен автокран"));
lead = await new W.Db(env.DB).getLead("p:" + CLIENT);
assert.equal(lead.date, undefined); assert.equal(lead.machine, "Автокран"); assert.match(aiCalls[0].input.messages[1].content, /: пока ничего\.$/);
ok("старая заявка не подмешивается: новая с чистого листа");

console.log("Бизнес-режим: личный аккаунт владельца");
reset();
await hook({ business_connection: { id: "EVIL", user: { id: 6660001, first_name: "Чужой" }, user_chat_id: 6660001, date: 0, is_enabled: true, rights: { can_reply: true } } });
assert.equal(sent((b) => b.chat_id === ADMIN).length, 0); assert.equal(await env.DB.prepare("SELECT * FROM conns WHERE id='EVIL'").first(), null);
bizOwner = 6660001; reset();
await hook({ business_message: { message_id: 1, business_connection_id: "EVIL2", date: Math.floor(Date.now() / 1000), chat: { id: 123, type: "private" }, from: { id: 123, first_name: "x" }, text: "привет" } });
assert.equal(aiCalls.length, 0); bizOwner = OWNER; ok("чужой аккаунт подключить бота не может");
reset();
await hook({ business_connection: { id: "BC1", user: { id: OWNER, first_name: "Марат" }, user_chat_id: OWNER, date: 0, is_enabled: true, rights: { can_reply: true } } });
assert.match(lastTo(ADMIN).body.text, /подключён к вашему аккаунту[\s\S]*НОВЫМ чатам/); ok("подключение владельца — уведомление с подсказкой про «новые чаты»");
const C6 = { id: 7770006, first_name: "Руслан", username: "ruslan_nk" };
const bmsg = (from, text, extra, chatId) => ({ business_message: Object.assign({ message_id: uid, business_connection_id: "BC1", date: Math.floor(Date.now() / 1000), chat: { id: chatId || C6.id, type: "private" }, from, text }, extra || {}) });
reset(); aiScript.push({ reply: "Здравствуйте! Я ИИ-помощник Марата, СпецТехИИ 24/7. Какой экскаватор нужен и где работаем?", machine: "Экскаватор", handoff: false });
await hook(bmsg(C6, "Здравствуйте, нужен экскаватор"));
ans = lastTo(C6.id).body;
assert.equal(ans.business_connection_id, "BC1"); assert.equal(ans.reply_markup, undefined); assert.match(ans.text, /ИИ-помощник Марата/);
assert.ok(calls.find((c) => c.method === "sendChatAction" && c.body.business_connection_id === "BC1"));
assert.match(aiCalls[0].input.messages[0].content, /в личном чате владельца компании Марата/); ok("клиент пишет вам в личку — ИИ отвечает от вашего аккаунта");
reset(); aiScript.push({ reply: "Понял: экскаватор-погрузчик, Челны, 29.09. Диспетчер свяжется.", machine: "Экскаватор-погрузчик", city: "Набережные Челны", address: "ул. Шамиля Усманова, 1", date: "29.09.2026", hours: "смена", handoff: false });
await hook(bmsg(C6, "JCB на Шамиля Усманова 1 в понедельник на смену"));
card = lastTo(ADMIN).body.text;
assert.match(card, /Новая заявка №\d+/); assert.match(card, /Написал вам в личку/); assert.match(card, /@ruslan_nk/); assert.match(card, /от 24 000 ₽ с НДС \(8 ч × 3 000 ₽\)/); ok("заявка из лички — карточка, смена = 8 ч, 24 000 ₽");
const cardB = Number(String((await env.DB.prepare("SELECT k FROM kv WHERE k LIKE 'card:%' AND v = ?").bind("b:" + OWNER + ":" + C6.id).first()).k).split(":")[1]);
reset(); await hook(bmsg({ id: OWNER, first_name: "Марат" }, "Руслан, это Марат, сейчас наберу"));
reset(); await hook(bmsg(C6, "жду"));
assert.equal(aiCalls.length, 0); assert.equal(sent().length, 0);
assert.equal(Number((await env.DB.prepare("SELECT paused_until FROM chats WHERE key = ?").bind("b:" + OWNER + ":" + C6.id).first()).paused_until), 4102444800000);
assert.equal((await env.DB.prepare("SELECT COUNT(*) AS n FROM msgs WHERE key = ? AND text = 'жду'").bind("b:" + OWNER + ":" + C6.id).first()).n, 0);
ok("вы написали сами — ИИ в этом чате больше не отвечает и переписку не сохраняет");
reset(); await hook(msg(A, "Руслан, подтверждаю на понедельник", { reply_to_message: { message_id: cardB } }));
assert.equal(lastTo(C6.id).body.business_connection_id, "BC1"); assert.match(lastTo(ADMIN).body.text, /от вашего имени/); ok("ответ на карточку из лички уходит клиенту от вашего имени");
const FRIEND = { id: 7770010, first_name: "Друг" };
reset(); await hook(bmsg({ id: OWNER, first_name: "Марат" }, "Привет, как дела?", {}, FRIEND.id));
assert.equal((await env.DB.prepare("SELECT COUNT(*) AS n FROM msgs WHERE key = ?").bind("b:" + OWNER + ":" + FRIEND.id).first()).n, 0);
reset(); await hook(bmsg(FRIEND, "Нормально, а ты?", {}, FRIEND.id));
assert.equal(aiCalls.length, 0); assert.equal(sent().length, 0); ok("чат, который вы начали сами, ИИ не трогает и не записывает");
const C7 = { id: 7770007, first_name: "Лена" };
reset(); await hook(bmsg({ id: OWNER, first_name: "Марат" }, "эхо", { sender_business_bot: { id: BOT_ID, is_bot: true } }, C7.id));
aiScript.push({ reply: "Какая техника нужна?", handoff: false });
await hook(bmsg(C7, "добрый день", {}, C7.id));
assert.equal(lastTo(C7.id).body.text, "Какая техника нужна?"); ok("собственные сообщения бота (эхо) не ставят чат на паузу");
reset(); aiHook = async () => sql("UPDATE chats SET paused_until = ? WHERE key = ?", 4102444800000, "b:" + OWNER + ":" + C7.id);
aiScript.push({ reply: "Это не должно уйти", handoff: false });
await hook(bmsg(C7, "нужен кран", {}, C7.id));
assert.equal(sent((b) => b.chat_id === C7.id).length, 0); ok("вы ответили, пока ИИ думал, — ответ ИИ не отправляется");
reset(); await hook(bmsg({ id: 7770011, first_name: "Старый" }, "старое", { date: 1000 }, 7770011));
assert.equal(aiCalls.length, 0); ok("старые сообщения до подключения игнорируются");

console.log("Команды владельца");
reset(); await hook(msg(A, "/leads"));
assert.match(lastTo(ADMIN).body.text, /№1 · .*Автовышка/); ok("/leads");
reset(); await hook(msg(A, "/lead 1"));
const two = sent((b) => b.chat_id === ADMIN);
assert.match(two[0].body.text, /Заявка №1/); assert.match(two[1].body.text, /Клиент: Нужна автовышка/); assert.match(two[1].body.text, /Вы: Иван, подтверждаю/); ok("/lead 1 — карточка и переписка");
sql("UPDATE leads SET name = ? WHERE no = 2", '=HYPERLINK("http://evil","x")');
reset(); await hook(msg(A, "/csv"));
const doc = calls.find((c) => c.method === "sendDocument");
assert.ok(doc); const csvBytes = new Uint8Array(await doc.body.document.arrayBuffer()); const csvText = new TextDecoder().decode(csvBytes);
assert.deepEqual([...csvBytes.slice(0, 3)], [0xEF, 0xBB, 0xBF]); assert.match(csvText, /"№";"Дата заявки"/); assert.match(csvText, /"'\+7 917 123-45-67"/); assert.match(csvText, /"'=HYPERLINK\(""http:\/\/evil""/);
ok("/csv — файл для Excel, формулы обезврежены");
reset(); await hook(msg(A, "/stats")); assert.match(lastTo(ADMIN).body.text, /Заявок: сегодня \d+/); ok("/stats");
reset(); await hook(msg(A, "/pause"));
const C9 = { id: 7770009, first_name: "Гость" };
reset(); await hook(msg(C9, "нужен кран"));
assert.equal(aiCalls.length, 0); assert.match(lastTo(ADMIN).body.text, /ИИ на паузе/); ok("/pause — ИИ молчит, сообщения идут владельцу");
reset(); await hook(msg(A, "/resume")); aiScript.push({ reply: "Какой вес груза?", handoff: false });
reset(); await hook(msg(C9, "автокран"));
assert.equal(aiCalls.length, 1); ok("/resume — ИИ снова отвечает");
reset(); await hook(msg(A, "/delete 1"));
assert.match(lastTo(ADMIN).body.text, /Удалено из базы бота/);
assert.equal((await env.DB.prepare("SELECT COUNT(*) AS n FROM msgs WHERE key = ?").bind("p:" + CLIENT).first()).n, 0);
assert.equal(await env.DB.prepare("SELECT * FROM leads WHERE key = ?").bind("p:" + CLIENT).first(), null);
assert.equal(await env.DB.prepare("SELECT * FROM kv WHERE v = ?").bind("p:" + CLIENT).first(), null); ok("/delete 1 — заявки, переписка и карточки клиента удалены");

console.log("Мелочи");
assert.equal(W.normPhone("8 (917) 123-45-67"), "+79171234567"); assert.equal(W.normPhone("9171234567"), "+79171234567"); assert.equal(W.normPhone("12345"), "");
assert.equal(W.findPhone("звоните +7 917 123 45 67 после 5"), "+79171234567"); assert.equal(W.findPhone("высота 18 м, 2026"), "");
assert.equal(W.matchMachine("воровайка")[0], "kmu"); assert.equal(W.matchMachine("JCB 3CX")[0], "exc"); assert.equal(W.matchMachine("экскаватор гусеничный")[0], "crawler");
assert.equal(W.matchMachine("каток по асфальту")[0], "aroller"); assert.equal(W.matchMachine("каток грунт уплотнить")[0], "roller"); assert.equal(W.matchMachine("миксер")[0], "mixer");
assert.equal(W.estimate({ machine: "миксер", hours: "3" }), ""); assert.equal(W.estimate({ machine: "Автокран", hours: "2 смены", qty: "2" }), "от 112 000 ₽ с НДС (2 × 16 ч × 3 500 ₽)");
assert.equal(W.estimate({ machine: "Автовышка", hours: "с 8 до 17" }), "от 24 300 ₽ с НДС (9 ч × 2 700 ₽)"); assert.equal(W.estimate({ machine: "Автовышка", hours: "полсмены" }), "от 10 800 ₽ с НДС (4 ч × 2 700 ₽)");
assert.deepEqual(W.parseAi("Текст без json"), { reply: "Текст без json" }); assert.throws(() => W.parseAi('{"machine":"x"'));
ok("телефоны, подбор техники по словам, ориентир (смены, «с 8 до 17», полсмены), разбор ответа ИИ");

console.log("\nВсе проверки пройдены: " + pass);
