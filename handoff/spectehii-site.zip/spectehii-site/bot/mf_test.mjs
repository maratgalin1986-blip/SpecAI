// Прогон в настоящем движке Cloudflare (workerd через Miniflare): D1 локально, ИИ — имитация по RPC, Telegram — перехват исходящих запросов.
import { Miniflare } from "miniflare";
import assert from "node:assert/strict";

const calls = [];
let msgId = 500;
const AI_MOCK = `
import { WorkerEntrypoint } from "cloudflare:workers";
export class AiMock extends WorkerEntrypoint {
  async run(model, input) {
    if (model.includes("whisper")) return { text: "нужен манипулятор" };
    const last = input.messages[input.messages.length - 1].content;
    if (!input.response_format) throw new Error("expected json mode");
    if (/автовышка/i.test(last)) return { response: { reply: "Здравствуйте! Я ИИ-помощник СпецТехИИ 24/7. Автовышка на завтра — во сколько подать и на сколько часов? Оставьте телефон для связи.", machine: "Автовышка (АГП)", city: "Набережные Челны", address: "пр. Мира, 52", date: "27.09.2026", task: "фасад, 18 м", handoff: false } };
    if (/Иван/.test(last)) return { response: JSON.stringify({ reply: "Спасибо! Диспетчер свяжется.", name: "Иван", phone: "+7 917 123-45-67", time: "08:00", hours: "4", handoff: false }) };
    return { response: { reply: "Уточните, пожалуйста.", handoff: false } };
  }
}
export default { fetch() { return new Response("ai mock"); } };`;

const mf = new Miniflare({
  workers: [
    {
      name: "bot", modules: true, scriptPath: "worker.js", compatibilityDate: "2025-09-01",
      d1Databases: { DB: "spectehii" },
      bindings: { BOT_TOKEN: "123456:TEST", SETUP_KEY: "длинный-ключ-для-теста", DEBOUNCE_MS: "300" },
      serviceBindings: { AI: { name: "aimock", entrypoint: "AiMock" } },
      outboundService: async (req) => {
        const url = new URL(req.url);
        if (url.hostname !== "api.telegram.org") return new Response("blocked", { status: 403 });
        const method = url.pathname.split("/").pop();
        const ct = req.headers.get("content-type") || "";
        let body = {};
        if (ct.includes("application/json")) body = await req.json();
        else if (ct.includes("multipart/form-data")) { const fd = await req.formData(); body = {}; for (const [k, v] of fd) body[k] = typeof v === "string" ? v : { name: v.name, text: await v.text(), size: v.size }; }
        calls.push({ method, body });
        const ok = (result) => Response.json({ ok: true, result });
        if (method === "getMe") return ok({ id: 1, username: "SpecTehII247_bot", can_connect_to_business: true });
        if (method === "sendMessage" || method === "sendDocument") return ok({ message_id: ++msgId });
        return ok(true);
      },
    },
    { name: "aimock", modules: true, script: AI_MOCK, compatibilityDate: "2025-09-01" },
  ],
});

const wait = async (pred, ms = 8000) => { const t = Date.now(); while (Date.now() - t < ms) { if (pred()) return true; await new Promise((r) => setTimeout(r, 25)); } return false; };
const BASE = "https://spectehii-bot.test.workers.dev";
try {
  let r = await mf.dispatchFetch(BASE + "/setup?key=" + encodeURIComponent("длинный-ключ-для-теста"));
  const page = await r.text();
  assert.equal(r.status, 200, page); assert.match(page, /Бот: @SpecTehII247_bot/);
  const secret = calls.find((c) => c.method === "setWebhook").body.secret_token;
  console.log("  ✔ workerd: /setup — база, вебхук, описание");
  let uid = 1;
  const post = async (upd) => mf.dispatchFetch(BASE + "/tg", { method: "POST", headers: { "content-type": "application/json", "x-telegram-bot-api-secret-token": secret }, body: JSON.stringify(Object.assign({ update_id: uid++ }, upd)) });
  const m = (from, text) => ({ message: { message_id: uid, chat: { id: from.id, type: "private" }, from, text } });
  const A = { id: 42, first_name: "Марат" }, U = { id: 77, first_name: "Иван", username: "ivan" };
  r = await post(m(A, "/admin длинный-ключ-для-теста")); assert.equal(r.status, 200);
  assert.ok(await wait(() => calls.some((c) => c.method === "sendMessage" && c.body.chat_id === 42 && /администратор/.test(c.body.text))));
  console.log("  ✔ workerd: владелец назначен");
  await post(m(U, "Нужна автовышка завтра на Мира 52"));
  assert.ok(await wait(() => calls.some((c) => c.method === "sendMessage" && c.body.chat_id === 77 && /privacy/.test(c.body.text))));
  await post(m(U, "Иван, 89171234567, к 8, часа 4"));
  assert.ok(await wait(() => calls.some((c) => c.method === "sendMessage" && c.body.chat_id === 42 && /Новая заявка №1/.test(c.body.text))));
  const card = calls.find((c) => c.method === "sendMessage" && c.body.chat_id === 42 && /Новая заявка/.test(c.body.text)).body.text;
  assert.match(card, /от 10 800 ₽ с НДС/); assert.match(card, /\+7 917 123-45-67/);
  console.log("  ✔ workerd: диалог → карточка заявки владельцу:\n" + card.split("\n").map((l) => "      " + l).join("\n"));
  await post(m(A, "/csv"));
  assert.ok(await wait(() => calls.some((c) => c.method === "sendDocument")));
  const doc = calls.find((c) => c.method === "sendDocument").body;
  assert.match(doc.document.name, /^zayavki_\d{4}-\d\d-\d\d\.csv$/); assert.match(doc.document.text, /"'\+7 917 123-45-67"/);
  console.log("  ✔ workerd: /csv — файл " + doc.document.name + ", " + doc.document.size + " байт");
  r = await mf.dispatchFetch(BASE + "/tg", { method: "POST", body: "{}" }); assert.equal(r.status, 403);
  console.log("  ✔ workerd: запрос без секрета — 403");
  const outside = calls.length;
  console.log("\nРеальный движок Cloudflare: все проверки пройдены. Запросов в Telegram: " + outside);
} finally {
  await mf.dispose();
}
