const { chromium } = require('playwright');
(async () => {
  const b = await chromium.launch(); const errs = [];
  const p = await b.newPage({viewport:{width:1280,height:900}});
  p.on('pageerror', e => errs.push(e.message));
  await p.goto('file://'+process.cwd()+'/preview.html'); await p.waitForTimeout(700);
  const st = async (label) => console.log(label,'|',await p.textContent('#sum'),'|',await p.textContent('#calc'),'|',await p.textContent('#vat'),'| lines:',await p.$$eval('.line .l-machine', s=>s.map(x=>x.value).join(',')),'| cnt',await p.textContent('#cntTop'), await p.isHidden('#cntTop'));
  await st('default');
  console.log('options:', await p.$$eval('.l-machine option', o=>o.length), await p.$$eval('.l-machine optgroup', o=>o.map(x=>x.label).join('/')));
  // price list adds
  await p.click('[data-add="grader"]'); await st('+grader');
  await p.click('[data-add="roller"]'); await st('+roller');
  await p.click('[data-add="mixer"]'); await st('+mixer');
  console.log('added btns:', await p.$$eval('.pl-add.added', b=>b.map(x=>x.dataset.add).join(',')), 'plGo hidden', await p.isHidden('#plGo'));
  console.log('breakdown:', await p.$$eval('#breakdown li', l=>l.map(x=>x.textContent).join(' / ')));
  console.log('msg:\n'+await p.textContent('#msg'));
  await p.locator('#road').screenshot({path:'v4_road.png'});
  await p.click('#kpBtn'); await p.waitForTimeout(400);
  console.log('kp:', await p.textContent('#kpTotal'), '|', await p.textContent('#kpVat'));
  await p.locator('#kp').screenshot({path:'v4_kp.png'});
  // fresh page: quiz
  const q = await b.newPage({viewport:{width:1280,height:900}}); q.on('pageerror', e => errs.push(e.message));
  await q.goto('file://'+process.cwd()+'/preview.html'); await q.waitForTimeout(500);
  await q.locator('#pick').screenshot({path:'v4_pick.png'});
  for (const [k,h] of [['excH','8'],['grader','12'],['drill','4'],['mixer',null],['truck',null]]) {
    await q.click(`#pane1 .opt[data-key="${k}"]`);
    if (h) await q.click(`#pane2 .opt[data-hours="${h}"]`);
    console.log('quiz',k,'|',await q.textContent('#rName'),'|',await q.textContent('#rSum'),'|',await q.textContent('#rCalc'),'| combo:',await q.isVisible('#rComboWrap')?await q.textContent('#rComboText'):'-');
    await q.click('#pickReset');
  }
  await q.click('#pane1 .opt[data-key="grader"]'); await q.click('#pane2 .opt[data-hours="8"]'); await q.check('#rCombo'); await q.click('#rUse'); await q.waitForTimeout(600);
  console.log('quiz grader+roller ->', await q.$$eval('.line .l-machine', s=>s.map(x=>x.value).join(',')), await q.textContent('#sum'), '|', await q.textContent('#vat'), '| task:', await q.$eval('#f-task',t=>t.value));
  // select change to pump -> hourly unpriced
  await q.locator('.line').nth(0).locator('.l-machine').selectOption('pump');
  console.log('pump only priced? ', await q.textContent('#sum'), '|', await q.textContent('#vat'));
  console.log('errors', errs);
  await b.close();
})();
