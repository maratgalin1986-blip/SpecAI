import os, shutil, datetime
DOMAIN = "spetsplast16.ru"
src = open('spetsplast16.html', encoding='utf-8').read()
i = src.index('<style>'); head = src[:i].strip(); rest = src[i:]
j = rest.index('</style>') + len('</style>'); style = rest[:j]; body = rest[j:].lstrip()
head = head.replace('<meta property="og:type"', '<link rel="canonical" href="https://%s/">\n<meta property="og:url" content="https://%s/">\n<meta property="og:type"' % (DOMAIN, DOMAIN), 1)
doc = ('<!doctype html>\n<html lang="ru">\n<head>\n<meta charset="utf-8">\n'
       '<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">\n'
       + head + '\n' + style + '\n</head>\n<body>\n' + body + '\n</body>\n</html>\n')
out = '/mnt/user-data/outputs/spetsplast16-site'
os.makedirs(out, exist_ok=True)
open(os.path.join(out, 'index.html'), 'w', encoding='utf-8').write(doc)
shutil.copy('privacy.html', os.path.join(out, 'privacy.html'))
shutil.copy('favicon.svg', os.path.join(out, 'favicon.svg'))
open(os.path.join(out, 'robots.txt'), 'w').write("User-agent: *\nAllow: /\nDisallow: /privacy.html\n\nSitemap: https://%s/sitemap.xml\n" % DOMAIN)
today = datetime.date.today().isoformat()
open(os.path.join(out, 'sitemap.xml'), 'w').write('<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n  <url><loc>https://%s/</loc><lastmod>%s</lastmod></url>\n</urlset>\n' % (DOMAIN, today))
print('built', len(doc))
