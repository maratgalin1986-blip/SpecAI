# Собирает версию 9 из версии 8: бренд «СпецТехИИ 24/7 от Спецпласт 16» + новые анимации
src = open('spetsplast16_v8.html', encoding='utf-8').read()

def rep(old, new, count=1):
    global src
    n = src.count(old)
    assert n == count, (n, old[:90])
    src = src.replace(old, new)

BM = ('<svg class="brand-mark" viewBox="0 0 40 40" aria-hidden="true"><rect class="bm-bg" width="40" height="40" rx="9"/>'
      '<circle class="bm-ring" cx="20" cy="20" r="14"/><circle class="bm-arc" cx="20" cy="20" r="14"/>'
      '<text class="bm-t" x="20" y="23.1" text-anchor="middle">24/7</text></svg>')
KPM = ('<svg class="kp-mark" viewBox="0 0 40 40" aria-hidden="true"><rect width="40" height="40" rx="9" fill="#1A1E1C"/>'
       '<circle cx="20" cy="20" r="14" fill="none" stroke="#FFFFFF" stroke-opacity=".22" stroke-width="2.4"/>'
       '<circle cx="20" cy="20" r="14" fill="none" stroke="#DD5A12" stroke-width="2.6" stroke-linecap="round" stroke-dasharray="24 64" transform="rotate(-90 20 20)"/>'
       '<text x="20" y="23.1" text-anchor="middle" fill="#FFFFFF" font-family="Unbounded, Arial Black, sans-serif" font-weight="800" font-size="8.6">24/7</text></svg>')
TRUCK = ('<svg viewBox="0 0 30 14"><rect class="pt-bed" x="1" y="3" width="16" height="6.5" rx="1"/>'
         '<path class="pt-cab" d="M18 11V4.5l2-2.5h5l3 4v5z"/>'
         '<g class="pt-wheel"><circle class="pt-w" cx="6" cy="11.3" r="2.4"/></g>'
         '<g class="pt-wheel"><circle class="pt-w" cx="12" cy="11.3" r="2.4"/></g>'
         '<g class="pt-wheel"><circle class="pt-w" cx="24" cy="11.3" r="2.4"/></g></svg>')

# --- мета и разметка ---
rep('<title>Спецпласт 16</title>', '<title>СпецТехИИ 24/7 — аренда спецтехники с экипажем в Набережных Челнах</title>')
rep('<meta name="description" content="Аренда спецтехники', '<meta name="description" content="СпецТехИИ 24/7 от Спецпласт 16: аренда спецтехники')
rep('<meta property="og:title" content="Спецпласт 16 — аренда спецтехники с экипажем">',
    '<meta property="og:site_name" content="СпецТехИИ 24/7">\n<meta property="og:title" content="СпецТехИИ 24/7 — аренда спецтехники с экипажем">')
rep('  "name": "Спецпласт 16",\n  "legalName"', '  "name": "СпецТехИИ 24/7",\n  "alternateName": "Спецпласт 16",\n  "url": "https://spetsplast16.ru/",\n  "legalName"')

# --- стили ---
rep('</style>\n\n<!-- Иконки техники', open('frag_v9.css', encoding='utf-8').read() + '</style>\n\n<!-- Иконки техники')

# --- шапка ---
rep('''    <a class="brand" href="#top" aria-label="Спецпласт 16 — в начало">
      <span class="brand-mark">С16</span>
      <span class="brand-name">Спецпласт 16<small>спецтехника с экипажем</small></span>
    </a>''', '''    <a class="brand" href="#top" aria-label="СпецТехИИ 24/7 от Спецпласт 16 — в начало">
      %s
      <span class="brand-name">СпецТех<span class="ai">ИИ</span><span class="b247">24/7</span><small>от Спецпласт 16</small></span>
    </a>''' % BM)
rep('  <div class="progress" id="progress" aria-hidden="true"></div>\n',
    '  <div class="progress" id="progress" aria-hidden="true"></div>\n  <div class="prog-truck" id="progTruck" aria-hidden="true">%s</div>\n' % TRUCK)

# --- первый экран ---
rep('<p class="eyebrow">Набережные Челны и Закамье</p>', '<p class="eyebrow">СпецТехИИ 24/7 · Набережные Челны и Закамье</p>')
rep('а&nbsp;не&nbsp;за&nbsp;простой.</h1>',
    'а&nbsp;не&nbsp;за&nbsp;простой.</h1>\n        <p class="hero-rot"><span class="sr">Подадим любую спецтехнику с машинистом</span><span aria-hidden="true">Подадим <span class="rot" id="rot"><span class="rot-w">автовышку</span></span> с&nbsp;машинистом</span></p>')
rep('<li>УПД и путевой лист по ЭДО</li></ul>', '<li>УПД и путевой лист по ЭДО</li><li>Смета и заявка онлайн 24/7</li></ul>')

# --- погода «сейчас» и города переезжают под путевой лист ---
a = src.index('        <div class="wx-now" id="wxNow" hidden></div>')
b = src.index('      <aside class="ticket"')
moved = src[a:b].rstrip()
assert moved.endswith('</div>\n      </div>') or moved.endswith('</div>\n      </div>'), moved[-60:]
moved_inner = moved[:moved.rindex('</div>')].rstrip()   # без закрывающего тега левой колонки
src = src[:a] + '      </div>\n\n' + src[b:]
c = src.index('      </aside>', src.index('<aside class="ticket"')) + len('      </aside>')
src = src[:c] + '\n' + moved_inner.replace('\n        ', '\n          ').replace('        <div class="wx-now"', '          <div class="wx-now"', 1) + '\n      </div>' + src[c:]
rep('      <aside class="ticket" aria-label="Пример путевого листа">', '      <div class="hero-side">\n      <aside class="ticket" aria-label="Пример путевого листа">')

# --- панорама между первым экраном и фактами ---
rep('  </section>\n\n  <div class="facts">', '  </section>\n' + open('frag_scene.html', encoding='utf-8').read() + '\n  <div class="facts">')

# --- КП, заявка, подвал ---
rep('<div class="kp-brand"><span class="kp-mark">С16</span><div><b>ООО «Спецпласт 16»</b><span>ИНН 1650412557',
    '<div class="kp-brand">%s<div><b>ООО «Спецпласт 16»</b><span>СпецТехИИ 24/7 · ИНН 1650412557' % KPM)
rep('var out = ["Заявка на спецтехнику — Спецпласт 16"];', 'var out = ["Заявка на спецтехнику — СпецТехИИ 24/7 (ООО «Спецпласт 16»)"];')
rep('<span>ООО «Спецпласт 16» · ИНН 1650412557 · ОГРН 1221600029287 · Набережные Челны</span>',
    '<span>СпецТехИИ 24/7 — бренд ООО «Спецпласт 16» · ИНН 1650412557 · ОГРН 1221600029287 · Набережные Челны</span>')

# --- оранжевая полоса ---
rep('''<div class="band">
    <div class="wrap">''', '''<div class="band">
    <span class="band-mark" aria-hidden="true">24/7</span>
    <div class="wrap">''')
rep('<a class="phone-big" href="tel:+79272428088">+7 927 242-80-88</a>',
    '<a class="phone-big" href="tel:+79272428088"><svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1z"/></svg>+7 927 242-80-88</a>')

# --- погода «сейчас» сообщает панораме ---
rep('''    el.hidden = false;
  }

  function initWx(){''', '''    el.hidden = false;
    var det = { kind: kindOf(iv.s), night: /_night$/.test(iv.s), t: fmtT(e.T) };
    window.__spWxNow = det;
    try { document.dispatchEvent(new CustomEvent("sp:wxnow", { detail: det })); } catch(err){}
  }

  function initWx(){''')

# --- скрипт v9 перед Метрикой ---
rep('<script>\n/* ---------- Яндекс Метрика', open('frag_v9.js', encoding='utf-8').read() + '<script>\n/* ---------- Яндекс Метрика')

open('spetsplast16.html', 'w', encoding='utf-8').write(src)
print('v9', len(src))
