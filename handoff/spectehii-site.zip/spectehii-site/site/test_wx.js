const { chromium } = require('playwright');
const fs = require('fs');
const real = JSON.parse(fs.readFileSync('real_met.json','utf8'));
function variant(fn){ const j = JSON.parse(JSON.stringify(real)); j.properties.timeseries.forEach(fn); return JSON.stringify(j); }
const windy = variant(e => { if (e.time >= '2026-09-28T05' && e.time <= '2026-09-28T13') e.data.instant.details.wind_speed = 16.2; });
const storm = variant(e => { if (e.time >= '2026-09-27T05' && e.time <= '2026-09-27T08') { e.data.next_1_hours = {summary:{symbol_code:'rainandthunder'},details:{precipitation_amount:2.4}}; } });
const icy = variant(e => { if (e.time.startsWith('2026-10-02')) { e.data.instant.details.air_temperature = 0.4; if (e.data.next_6_hours){ e.data.next_6_hours.details.precipitation_amount = 1.2; e.data.next_6_hours.summary.symbol_code='sleet'; e.data.next_6_hours.details.air_temperature_min=-0.5; e.data.next_6_hours.details.air_temperature_max=1; } } });
async function page(b, body, opts={}){
  const p = await b.newPage(Object.assign({viewport:{width:1280,height:900}}, opts));
  p.errs = []; p.on('pageerror', e => p.errs.push(e.message));
  let calls = 0;
  await p.route('https://api.met.no/**', r => { calls++; if (body === 'FAIL') return r.abort(); r.fulfill({status:200, contentType:'application/json', headers:{'access-control-allow-origin':'*'}, body}); });
  p.calls = () => calls;
  await p.goto('file://'+process.cwd()+'/index_full.html'); await p.waitForTimeout(900);
  return p;
}
const txt = async (p, sel) => (await p.textContent(sel)).replace(/\s+/g,' ').trim();
(async () => {
  const b = await chromium.launch();
  // 1. real data
  const p = await page(b, JSON.stringify(real));
  console.log('NOW CHIP:', await txt(p,'#wxNow'), '| hidden', await p.$eval('#wxNow', e=>e.hidden));
  console.log('DAYS:', await p.$$eval('.wx-day', d=>d.map(x=>x.innerText.replace(/\s+/g,' ')).join(' || ')));
  console.log('ORDER WX:', await txt(p,'#wxOrder'));
  console.log('MSG:\n'+await p.textContent('#msg'));
  console.log('API calls:', p.calls(), '| errors:', p.errs);
  await p.locator('#weather').screenshot({path:'w_section.png'});
  await p.locator('#order .order').screenshot({path:'w_order.png'});
  await p.locator('.hero').screenshot({path:'w_hero.png'});
  // click a day card (3rd) -> sets date
  await p.click('.wx-day:nth-child(4)'); await p.waitForTimeout(700);
  console.log('after click day4: f-day', await p.$eval('#f-day', e=>e.value), '|', await txt(p,'#wxOrder'));
  // KP
  await p.click('#kpBtn'); await p.waitForTimeout(400);
  console.log('KP meta:', await txt(p,'#kpMeta'));
  // beyond forecast
  await p.$eval('#f-day', e=>{ e.value='2026-10-12'; e.dispatchEvent(new Event('change')); }); await p.waitForTimeout(300);
  console.log('BEYOND:', await txt(p,'#wxOrder'));
  await p.$eval('#f-day', e=>{ e.value='2026-09-25'; e.dispatchEvent(new Event('change')); }); await p.waitForTimeout(300);
  console.log('PAST:', await txt(p,'#wxOrder'));
  // city change -> new fetch
  await p.selectOption('#f-city','nk'); await p.waitForTimeout(700);
  console.log('city nk -> wxCity', await p.$eval('#wxCity', e=>e.value), '| calls', p.calls());
  // 2. windy, lift vs non-lift
  const w = await page(b, windy);
  await w.$eval('#f-day', e=>{ e.value='2026-09-28'; e.dispatchEvent(new Event('change')); }); await w.waitForTimeout(300);
  console.log('WINDY AGP:', await txt(w,'#wxOrder'));
  await w.locator('.line .l-machine').first().selectOption('exc'); await w.waitForTimeout(300);
  console.log('WINDY EXC:', await txt(w,'#wxOrder'));
  console.log('WINDY day card 28:', await w.$eval('.wx-day[data-day="2026-09-28"]', e=>e.innerText.replace(/\s+/g,' ')));
  // 3. storm
  const s = await page(b, storm);
  console.log('STORM 27 08:00:', await txt(s,'#wxOrder'));
  // 4. icy
  const ic = await page(b, icy);
  await ic.$eval('#f-day', e=>{ e.value='2026-10-02'; e.dispatchEvent(new Event('change')); }); await ic.waitForTimeout(300);
  console.log('ICY:', await txt(ic,'#wxOrder'));
  // 5. fail
  const f = await page(b, 'FAIL'); await f.waitForTimeout(500);
  console.log('FAIL order:', await txt(f,'#wxOrder'), '| section:', await txt(f,'#wxDays'), '| chip hidden', await f.$eval('#wxNow', e=>e.hidden), '| errs', f.errs);
  // 6. mobile + dark + reduced
  const m = await page(b, JSON.stringify(real), {viewport:{width:390,height:844}});
  console.log('mobile sw', await m.evaluate(()=>document.documentElement.scrollWidth));
  await m.addStyleTag({content:'.top,.mbar{position:static!important}'});
  await m.locator('#weather').screenshot({path:'w_m_section.png'}); await m.locator('#order .form').screenshot({path:'w_m_form.png'});
  const k = await page(b, JSON.stringify(real), {colorScheme:'dark'}); await k.locator('#weather').screenshot({path:'w_k_section.png'});
  console.log('all errs', [p,w,s,ic,m,k].map(x=>x.errs).flat());
  await b.close();
})();
