const { chromium } = require('playwright');
const fs = require('fs');
const MET = fs.readFileSync('real_met.json', 'utf8');
const URL = 'file://' + process.cwd() + '/preview.html';
const FDIR = '/tmp/claude-0/-home-claude/e32f183d-f4d4-592a-875b-7594b6eb45c9/scratchpad/fonts/node_modules/@fontsource/';
const FF = [['Unbounded','unbounded',[500,700,800]],['Golos Text','golos-text',[400,500,600]],['IBM Plex Mono','ibm-plex-mono',[500,600]]];
let FONTCSS = '';
for (const [fam, dir, ws] of FF) for (const w of ws) for (const sub of ['cyrillic','latin']) FONTCSS += `@font-face{font-family:'${fam}';font-weight:${w};font-display:swap;src:url(https://fonts.gstatic.com/local/${dir}/files/${dir}-${sub}-${w}-normal.woff2) format('woff2');unicode-range:${sub==='cyrillic'?'U+0400-045F,U+0490-0491,U+04B0-04B1,U+2116':'U+0000-00FF,U+2000-206F,U+20AC,U+20BD,U+2122,U+2212'}}\n`;
(async () => {
  const b = await chromium.launch(); const errs = [];
  async function page(opts, tag){
    const p = await b.newPage(opts);
    p.on('pageerror', e => errs.push(tag + ': ' + e.message));
    p.on('console', m => { if (m.type() === 'error' && !/ERR_|net::|Failed to load resource/.test(m.text())) errs.push(tag + ' console: ' + m.text()); });
    await p.route('**/api.met.no/**', r => r.fulfill({ status: 200, contentType: 'application/json', body: MET }));
    await p.route('**/fonts.googleapis.com/**', r => r.fulfill({ status: 200, contentType: 'text/css', body: FONTCSS }));
    await p.route('**/fonts.gstatic.com/local/**', r => { const f = r.request().url().split('/local/')[1]; r.fulfill({ status: 200, contentType: 'font/woff2', body: fs.readFileSync(FDIR + f) }); });
    await p.goto(URL); return p;
  }
  // --- ПК ---
  const p = await page({ viewport: { width: 1280, height: 900 } }, 'desk');
  await p.waitForTimeout(1800);
  console.log('fonts:', await p.evaluate(() => [...document.fonts].filter(f => f.status === 'loaded').map(f => f.family + ' ' + f.weight).join(', ')));
  await p.screenshot({ path: 'v9_d_top.png' });
  console.log('title:', await p.title());
  console.log('scene daypart:', await p.$eval('#scene', e => e.dataset.daypart), '| wx:', await p.$eval('#scene', e => e.dataset.wx), '| clock:', await p.textContent('#scClock'), '| inview', await p.$eval('#scene', e => e.classList.contains('inview')));
  console.log('sun times MSK:', await p.evaluate(() => window.spSunTimes(Date.now()).map(t => new Date(t + 3*3600e3).toISOString().slice(11, 16)).join(' – ')));
  const w1 = await p.textContent('#rot'); await p.waitForTimeout(2700); const w2 = await p.textContent('#rot');
  console.log('rot words:', w1, '->', w2, '| rot width', await p.$eval('#rot', e => e.style.width));
  // кадры панорамы
  for (const t of [0, 1500, 2600, 6000, 8500, 9600, 12500]){
    await p.evaluate(t => document.getAnimations().forEach(a => { a.pause(); a.currentTime = t; }), t);
    await p.locator('#scene').screenshot({ path: 'v9_scene_' + t + '.png' });
  }
  await p.evaluate(() => document.getAnimations().forEach(a => a.play()));
  // ночь и дождь
  await p.evaluate(() => { const s = document.getElementById('scene'); s.dataset.daypart = 'night'; document.dispatchEvent(new CustomEvent('sp:wxnow', { detail: { kind: 'rain', t: '+8°' } })); });
  await p.waitForTimeout(1500); await p.locator('#scene').screenshot({ path: 'v9_scene_night_rain.png' });
  await p.evaluate(() => { document.dispatchEvent(new CustomEvent('sp:wxnow', { detail: { kind: 'snow', t: '−3°' } })); document.getElementById('scene').dataset.daypart = 'day'; });
  await p.waitForTimeout(1500); await p.locator('#scene').screenshot({ path: 'v9_scene_snow.png' });
  console.log('snow particles:', await p.$$eval('#sceneWx i', e => e.length));
  // прокрутка: грузовик, заголовки, шаги
  await p.mouse.move(640, 300);
  const H = await p.evaluate(() => document.documentElement.scrollHeight);
  for (let y = 0; y < H; y += 450){ await p.evaluate(y => window.scrollTo(0, y), y); await p.waitForTimeout(90); }
  await p.waitForTimeout(600);
  console.log('truck:', await p.$eval('#progTruck', e => e.style.transform + ' op=' + getComputedStyle(e).opacity));
  console.log('drawn h2:', await p.$$eval('h2.drawn', e => e.length), 'of', await p.$$eval('.section-head h2, .geo h2, .docs h2', e => e.length), '| steps drawn', await p.$eval('.steps', e => e.classList.contains('drawn')));
  console.log('glow:', await p.$$eval('.glow', e => e.length), 'tilt:', await p.$$eval('.tilt', e => e.length), '| left .reveal', await p.$$eval('.reveal:not(.in)', e => e.length));
  await p.evaluate(() => document.getElementById('how').scrollIntoView({ block: 'center' })); await p.waitForTimeout(3200);
  await p.locator('#how').screenshot({ path: 'v9_d_steps.png' });
  // FAQ
  await p.evaluate(() => document.getElementById('faq').scrollIntoView({ block: 'start' })); await p.waitForTimeout(500);
  const q = p.locator('.faq details').nth(2);
  await q.locator('summary').click(); await p.waitForTimeout(120);
  const midH = await q.evaluate(e => e.getBoundingClientRect().height); await p.waitForTimeout(400);
  const fullH = await q.evaluate(e => e.getBoundingClientRect().height);
  console.log('faq open:', await q.evaluate(e => e.open), 'h mid/full', Math.round(midH), Math.round(fullH));
  await q.locator('summary').click(); await p.waitForTimeout(450);
  console.log('faq closed:', !(await q.evaluate(e => e.open)), 'h', Math.round(await q.evaluate(e => e.getBoundingClientRect().height)));
  // волна и наклон
  await p.evaluate(() => document.getElementById('fleet').scrollIntoView({ block: 'start' })); await p.waitForTimeout(900);
  const card = p.locator('#fleet .card').nth(1); const bb = await card.boundingBox();
  await p.mouse.move(bb.x + bb.width * 0.8, bb.y + bb.height * 0.2); await p.waitForTimeout(400);
  console.log('tilt vars:', await card.evaluate(e => e.style.getPropertyValue('--rx') + ' ' + e.style.getPropertyValue('--ry') + ' | ' + getComputedStyle(e).transform.slice(0, 40)));
  await p.locator('#fleet .fleet').screenshot({ path: 'v9_d_fleet_tilt.png' });
  await p.mouse.down(); const rips = await p.$$eval('.rip', e => e.length); await p.mouse.up();
  await card.locator('button').dispatchEvent('pointerdown', { clientX: bb.x + 30, clientY: bb.y + bb.height - 30 });
  console.log('ripple spans after pointerdown on button:', await p.$$eval('.rip', e => e.length));
  await p.evaluate(() => document.querySelector('.band').scrollIntoView({ block: 'center' })); await p.waitForTimeout(800);
  await p.locator('.band').screenshot({ path: 'v9_d_band.png' });
  await p.evaluate(() => document.getElementById('kpBtn').click()); await p.waitForTimeout(500);
  await p.locator('.kp-head').screenshot({ path: 'v9_d_kp.png' });
  console.log('msg head:', (await p.textContent('#msg')).split('\n')[0]);
  console.log('desk sw', await p.evaluate(() => document.documentElement.scrollWidth));
  await p.evaluate(() => window.scrollTo(0, document.documentElement.scrollHeight)); await p.waitForTimeout(400);
  await p.screenshot({ path: 'v9_d_bottom.png' });

  // --- телефон ---
  const m = await page({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true }, 'mob');
  await m.waitForTimeout(1800); await m.screenshot({ path: 'v9_m_top.png' });
  await m.evaluate(() => document.getElementById('scene').scrollIntoView({ block: 'center' })); await m.waitForTimeout(600);
  await m.screenshot({ path: 'v9_m_scene.png' });
  console.log('mobile sw', await m.evaluate(() => document.documentElement.scrollWidth), '| glow on touch', await m.$$eval('.glow', e => e.length));
  await m.evaluate(() => document.querySelector('.band').scrollIntoView({ block: 'center' })); await m.waitForTimeout(500);
  await m.screenshot({ path: 'v9_m_band.png' });
  const m3 = await page({ viewport: { width: 360, height: 780 }, isMobile: true, hasTouch: true }, 'mob360');
  await m3.waitForTimeout(1200); await m3.screenshot({ path: 'v9_m360_top.png' });
  console.log('360 sw', await m3.evaluate(() => document.documentElement.scrollWidth));
  // --- планшет ---
  const t = await page({ viewport: { width: 768, height: 1024 } }, 'tab');
  await t.waitForTimeout(1500); await t.screenshot({ path: 'v9_t_top.png' });
  console.log('tab sw', await t.evaluate(() => document.documentElement.scrollWidth));
  // --- тёмная ---
  const k = await page({ viewport: { width: 1280, height: 900 }, colorScheme: 'dark' }, 'dark');
  await k.waitForTimeout(1800); await k.screenshot({ path: 'v9_k_top.png' });
  await k.evaluate(() => { document.getElementById('scene').dataset.daypart = 'night'; }); await k.waitForTimeout(1400);
  await k.locator('#scene').screenshot({ path: 'v9_k_scene_night.png' });
  await k.evaluate(() => document.querySelector('.band').scrollIntoView({ block: 'center' })); await k.waitForTimeout(600);
  await k.locator('.band').screenshot({ path: 'v9_k_band.png' });
  // --- меньше движения ---
  const r = await page({ viewport: { width: 1280, height: 900 }, reducedMotion: 'reduce' }, 'rm');
  await r.waitForTimeout(1500);
  console.log('RM: rot', await r.textContent('#rot'), '| drawn', await r.$$eval('h2.drawn', e => e.length), '| drops', await r.$$eval('#sceneWx i', e => e.length), '| arc anim', await r.$eval('.bm-arc', e => getComputedStyle(e).animationName), '| svg paused', await r.$eval('#scene svg', e => e.animationsPaused()));
  await r.screenshot({ path: 'v9_rm_top.png' });
  console.log('errors:', errs.length ? errs : 'нет');
  await b.close();
})();
