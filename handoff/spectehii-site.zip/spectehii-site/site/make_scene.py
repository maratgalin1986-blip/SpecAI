# Генератор живой панорамы стройки для первого экрана (v9)
import random
random.seed(16)

# --- дальний план: силуэт города, окна загораются ночью ---
bld, wins = [], []
x = -600
while x < 1800:
    w = random.randint(34, 66); h = random.randint(26, 82)
    bld.append('<rect x="%d" y="%d" width="%d" height="%d"/>' % (x, 176 - h, w, h))
    cols, rows = max(1, (w - 10) // 9), max(1, (h - 14) // 11)
    for c in range(cols):
        for r in range(rows):
            if random.random() < 0.3:
                cls = "fl" if random.random() < 0.12 else ""
                d = ' style="animation-delay:-%.1fs"' % (random.random() * 9) if cls else ""
                wins.append('<rect%s x="%d" y="%d" width="4" height="5"%s/>' % (' class="fl"' if cls else "", x + 6 + c * 9, 176 - h + 8 + r * 11, d))
    x += w + random.randint(2, 10)

stars = "".join('<circle cx="%d" cy="%d" r="%.1f" style="animation-delay:-%.1fs"/>' % (random.randint(-550, 1750), random.randint(6, 74), random.uniform(.7, 1.5), random.random() * 4) for _ in range(30))

def cloud(y, s, dur, delay):
    return ('<g transform="translate(0 %d)"><g class="sc-cloud" style="animation-duration:%ds;animation-delay:-%ds">'
            '<path transform="scale(%.2f)" d="M10 30h40a10 10 0 0 0 0-20 14 14 0 0 0-26.5-4A10 10 0 0 0 10 30z"/></g></g>') % (y, dur, delay, s)

def bird(y, dur, delay, s):
    return ('<g transform="translate(0 %d)"><g class="sc-bird" style="animation-duration:%ds;animation-delay:-%ds"><g transform="scale(%.2f)"><path class="sc-wing" d="M0 0q6-6 12 0q6-6 12 0"/></g></g></g>') % (y, dur, delay, s)

# мачта крана: решётка
mast = "M712 176"
y, left = 176, True
while y > 44:
    y -= 14
    mast += " L%d %d" % (728 if left else 712, y)
    left = not left
jib = "M728 38"
xx, up = 728, True
while xx < 952:
    xx += 12
    jib += " L%d %d" % (xx, 30 if up else 38)
    up = not up

def tree(x, h, r):
    return '<path class="sc-line" d="M%d 176v-%d"/><circle class="sc-tree" cx="%d" cy="%d" r="%d"/>' % (x, h, x, 176 - h - r + 4, r)
trees = "".join(tree(x, h, r) for x, h, r in [(-470, 22, 14), (-440, 16, 10), (-250, 24, 15), (-120, 18, 11), (1250, 20, 12), (1290, 26, 16), (1600, 22, 14), (1640, 16, 10), (1720, 24, 15)])

scene = '''
  <div class="scene" id="scene" aria-hidden="true" data-daypart="day">
    <svg class="scene-svg" viewBox="-560 0 2320 190" preserveAspectRatio="xMidYMax slice" focusable="false">
      <defs>
        <linearGradient id="scBeam" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3FA7FF" stop-opacity=".45"/><stop offset="1" stop-color="#3FA7FF" stop-opacity="0"/></linearGradient>
        <radialGradient id="scLamp"><stop offset="0" stop-color="#FFD66B" stop-opacity=".75"/><stop offset="1" stop-color="#FFD66B" stop-opacity="0"/></radialGradient>
      </defs>
      <g class="sc-sky">
        <g class="sc-stars">%(stars)s</g>
        <g class="sc-sun" transform="translate(1000 42)"><g class="sc-rays"><path d="M0-27v8M0 19v8M-27 0h8M19 0h8M-19.1-19.1l5.7 5.7M13.4 13.4l5.7 5.7M-19.1 19.1l5.7-5.7M13.4-13.4l5.7-5.7"/></g><circle r="12"/></g>
        <g class="sc-moon" transform="translate(1000 42)"><path d="M3-15a15 15 0 1 0 12 24A12 12 0 0 1 3-15z"/></g>
        <g class="sc-clouds">%(clouds)s</g>
        <g class="sc-birds">%(birds)s</g>
      </g>

      <g class="sc-far">
        <g class="sc-city">%(bld)s</g>
        <g class="sc-wins">%(wins)s</g>
      </g>

      <g class="sc-mid">
        <g class="sc-trees">%(trees)s</g>
        <!-- щит у дороги -->
        <g class="sc-board">
          <path class="sc-line" d="M1396 176v-40M1500 176v-40"/>
          <rect class="sc-body" x="1370" y="104" width="156" height="36" rx="3"/>
          <text class="sc-board-t" x="1448" y="119" text-anchor="middle">СМЕТА И ЗАЯВКА</text>
          <text class="sc-board-a" x="1448" y="133" text-anchor="middle">онлайн 24/7</text>
        </g>
        <!-- каток -->
        <g class="sc-roller">
          <path class="sc-body" d="M178 166v-16h58v16z"/>
          <path class="sc-body" d="M206 150v-20h26v20"/>
          <path class="sc-line" d="M202 130h34"/>
          <rect class="sc-glass" x="210" y="134" width="18" height="10" rx="1.5"/>
          <circle class="sc-body" cx="230" cy="168" r="8"/>
          <g class="sc-drum"><circle class="sc-body" cx="170" cy="164" r="12"/><path class="sc-line" d="M170 152v24M158 164h24"/></g>
          <circle class="sc-beacon" cx="222" cy="127" r="2.6"/>
        </g>

        <!-- экскаватор -->
        <g class="sc-exc">
          <path class="sc-dirt" d="M482 176q22-26 48 0z"/>
          <rect class="sc-body" x="340" y="164" width="92" height="12" rx="6"/>
          <g class="sc-line"><circle cx="352" cy="170" r="3.5"/><circle cx="370" cy="170" r="3.5"/><circle cx="388" cy="170" r="3.5"/><circle cx="406" cy="170" r="3.5"/><circle cx="421" cy="170" r="3.5"/></g>
          <path class="sc-body" d="M346 162v-18q0-4 4-4h60v22z"/>
          <path class="sc-body" d="M382 140v-20h22l4 20"/>
          <rect class="sc-glass" x="387" y="124" width="14" height="12" rx="1.5"/>
          <g class="sc-boom">
            <path class="sc-acc" d="M404 150l40-38 9 5-39 39z"/>
            <g class="sc-stick">
              <path class="sc-acc" d="M445 113l28 38-7 5-27-37z"/>
              <path class="sc-ink" d="M464 152l16 3-3 13-13-6z"/>
            </g>
          </g>
          <g class="sc-crumbs"><circle cx="486" cy="160" r="2"/><circle cx="492" cy="156" r="1.6"/><circle cx="480" cy="154" r="1.4"/></g>
        </g>

        <!-- забор стройки с баннером -->
        <g class="sc-fence">
          <rect class="sc-banner" x="540" y="144" width="170" height="30" rx="2"/>
          <text class="sc-banner-t" x="625" y="164" text-anchor="middle">СПЕЦТЕХИИ 24/7</text>
          <path class="sc-line" d="M540 176v-34M710 176v-34"/>
        </g>

        <!-- строящийся дом -->
        <g class="sc-house">
          <rect class="sc-body" x="770" y="136" width="90" height="40"/>
          <g class="sc-hwin"><rect x="778" y="142" width="10" height="7"/><rect x="796" y="142" width="10" height="7"/><rect x="814" y="142" width="10" height="7"/><rect x="832" y="142" width="10" height="7"/><rect x="778" y="158" width="10" height="7"/><rect x="796" y="158" width="10" height="7"/><rect x="814" y="158" width="10" height="7"/><rect x="832" y="158" width="10" height="7"/></g>
          <path class="sc-line" d="M772 136v-24M800 136v-24M830 136v-24M858 136v-24M770 124h90M770 112h90"/>
        </g>

        <!-- штабель плит -->
        <g class="sc-stack"><rect class="sc-body" x="904" y="168" width="32" height="8"/><rect class="sc-body" x="904" y="160" width="32" height="8"/><rect class="sc-body sc-stack-top" x="904" y="152" width="32" height="8"/></g>

        <!-- башенный кран -->
        <g class="sc-crane">
          <path class="sc-line" d="M712 176V38M728 176V38"/>
          <path class="sc-thin" d="%(mast)s"/>
          <rect class="sc-ink" x="700" y="170" width="40" height="6"/>
          <path class="sc-line" d="M650 30h310M650 38h310"/>
          <path class="sc-thin" d="%(jib)s"/>
          <path class="sc-line" d="M712 30l8-24 8 24"/>
          <path class="sc-thin" d="M720 6L956 30M720 6L652 30"/>
          <rect class="sc-muted" x="652" y="38" width="26" height="16"/>
          <rect class="sc-body" x="728" y="38" width="17" height="13" rx="1.5"/>
          <rect class="sc-glass" x="731" y="41" width="11" height="6" rx="1"/>
          <circle class="sc-avia" cx="720" cy="5" r="2.8"/>
          <g class="sc-trolley">
            <rect class="sc-ink" x="913" y="38" width="14" height="5"/>
            <rect class="sc-cable" x="919.2" y="43" width="1.6" height="17"/>
            <g class="sc-hook">
              <path class="sc-line" d="M920 60v5M916 65a4 4 0 1 0 8 0"/>
              <g class="sc-load"><g class="sc-swing">
                <path class="sc-thin" d="M920 69L906 76M920 69L934 76"/>
                <rect class="sc-acc" x="904" y="76" width="32" height="8"/>
              </g></g>
            </g>
          </g>
        </g>

        <!-- дрон-геодезист -->
        <g class="sc-drone">
          <animateMotion dur="24s" repeatCount="indefinite" path="M470 92C520 70 590 98 640 80S700 58 668 96S520 112 470 92z"/>
          <path class="sc-beam" d="M0 5L-18 62H18z"/>
          <path class="sc-line" d="M-12-2h24"/>
          <rect class="sc-ink" x="-6" y="-2" width="12" height="6" rx="2"/>
          <ellipse class="sc-rotor" cx="-12" cy="-4" rx="6" ry="1.5"/>
          <ellipse class="sc-rotor" cx="12" cy="-4" rx="6" ry="1.5"/>
          <circle class="sc-eye" cx="0" cy="1" r="1.4"/>
        </g>

        <!-- автовышка у фонаря -->
        <g class="sc-agp">
          <circle class="sc-glow" cx="1152" cy="70" r="30"/>
          <path class="sc-line" d="M1172 176V72q0-10-10-10h-6"/>
          <path class="sc-ink" d="M1140 62h18l-3 6h-12z"/>
          <path class="sc-body" d="M976 172v-22l6-10h22v32z"/>
          <rect class="sc-glass" x="983" y="144" width="12" height="9" rx="1.5"/>
          <path class="sc-body" d="M1004 170v-10h98v10z"/>
          <path class="sc-line" d="M1016 170v6h-6M1092 170v6h6"/>
          <circle class="sc-body" cx="990" cy="170" r="7"/><circle class="sc-body" cx="1062" cy="170" r="7"/><circle class="sc-body" cx="1080" cy="170" r="7"/>
          <circle class="sc-beacon" cx="992" cy="137" r="2.6"/>
          <g class="sc-arm">
            <path class="sc-acc-line" d="M1064 158L1126 94"/>
            <path class="sc-line sc-half" d="M1070 160L1130 98"/>
            <g class="sc-basket">
              <path class="sc-line" d="M1128 96v-4"/>
              <rect class="sc-body" x="1118" y="80" width="22" height="12" rx="1.5"/>
              <circle class="sc-ink" cx="1128" cy="74" r="3.2"/>
              <path class="sc-line" d="M1128 77v4M1128 79l9-6"/>
            </g>
          </g>
          <circle class="sc-ink" cx="1064" cy="158" r="3"/>
        </g>
      </g>

      <g class="sc-near">
        <rect class="sc-road" x="-620" y="176" width="2440" height="16"/>
        <path class="sc-ground" d="M-620 176H1820"/>
        <path class="sc-dash" d="M-620 185H1820"/>
        <!-- миксер едет влево -->
        <g class="sc-mixer"><g transform="translate(0 0)">
          <path class="sc-body" d="M0 174v-18l5-9h18v27z"/>
          <rect class="sc-glass" x="5" y="150" width="11" height="8" rx="1.5"/>
          <path class="sc-line" d="M23 174h74"/>
          <path class="sc-line" d="M34 174v-9M80 174v-14"/>
          <path class="sc-body" d="M83 151l3-9h9l-4 9z"/>
          <ellipse class="sc-drum-m" cx="58" cy="158" rx="30" ry="13" transform="rotate(-12 58 158)"/>
          <ellipse class="sc-drum-s" cx="58" cy="158" rx="22" ry="8" transform="rotate(-12 58 158)"/>
          <g class="sc-wheel"><circle class="sc-body" cx="12" cy="176" r="6"/><path class="sc-line" d="M12 172v8"/></g>
          <g class="sc-wheel"><circle class="sc-body" cx="66" cy="176" r="6"/><path class="sc-line" d="M66 172v8"/></g>
          <g class="sc-wheel"><circle class="sc-body" cx="81" cy="176" r="6"/><path class="sc-line" d="M81 172v8"/></g>
        </g></g>
        <!-- самосвал едет вправо -->
        <g class="sc-truck"><g class="sc-bounce">
          <path class="sc-dirt" d="M6 152q14-12 30-4q16-8 30 4z"/>
          <path class="sc-acc" d="M2 152h70l-4 22H6z"/>
          <path class="sc-body" d="M76 178v-26l6-8h18l6 12v22z"/>
          <rect class="sc-glass" x="84" y="147" width="15" height="9" rx="1.5"/>
          <path class="sc-line" d="M2 178h104"/>
          <g class="sc-wheel"><circle class="sc-body" cx="18" cy="181" r="8"/><path class="sc-line" d="M18 176v10M13 181h10"/></g>
          <g class="sc-wheel"><circle class="sc-body" cx="38" cy="181" r="8"/><path class="sc-line" d="M38 176v10M33 181h10"/></g>
          <g class="sc-wheel"><circle class="sc-body" cx="92" cy="181" r="8"/><path class="sc-line" d="M92 176v10M87 181h10"/></g>
        </g></g>
      </g>
    </svg>
    <div class="scene-wx" id="sceneWx"></div>
    <div class="wrap scene-tag"><span class="scene-chip"><i class="live-dot"></i>Наб. Челны · <b class="num" id="scClock">--:--</b></span></div>
  </div>
''' % dict(stars=stars, clouds=cloud(18, 1.0, 150, 10) + cloud(46, 0.8, 190, 70) + cloud(10, 1.3, 220, 100) + cloud(30, 0.9, 170, 140),
           birds=bird(58, 70, 8, 0.8) + bird(70, 80, 40, 0.6), bld="".join(bld), wins="".join(wins), mast=mast, jib=jib, trees=trees)

open('frag_scene.html', 'w', encoding='utf-8').write(scene)
print(len(scene), 'buildings', len(bld), 'windows', len(wins))
