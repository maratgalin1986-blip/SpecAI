<script>
/* ---------- v9: панорама, грузовик прогресса, сменяющиеся слова, подсветка, волны, шаги, вопросы ---------- */
(function(){
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
  var fine = window.matchMedia && matchMedia("(hover: hover) and (pointer: fine)").matches;
  var hasIO = "IntersectionObserver" in window;
  var MSK = 3 * 3600e3;
  var $ = function(id){ return document.getElementById(id); };
  var pad = function(n){ return (n < 10 ? "0" : "") + n; };
  var each = function(sel, fn){ Array.prototype.forEach.call(document.querySelectorAll(sel), fn); };

  /* восход и закат в Набережных Челнах (55.74° с.ш., 52.40° в.д.) */
  function sunTimes(ms){
    var d = new Date(ms), rad = Math.PI / 180, lat = 55.74 * rad, lon = 52.40;
    var day0 = Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
    var doy = Math.round((day0 - Date.UTC(d.getUTCFullYear(), 0, 1)) / 864e5) + 1;
    var g = 2 * Math.PI / 365 * (doy - 1);
    var decl = 0.006918 - 0.399912 * Math.cos(g) + 0.070257 * Math.sin(g) - 0.006758 * Math.cos(2 * g) + 0.000907 * Math.sin(2 * g) - 0.002697 * Math.cos(3 * g) + 0.00148 * Math.sin(3 * g);
    var eqt = 229.18 * (0.000075 + 0.001868 * Math.cos(g) - 0.032077 * Math.sin(g) - 0.014615 * Math.cos(2 * g) - 0.040849 * Math.sin(2 * g));
    var cosH = (Math.cos(90.833 * rad) - Math.sin(lat) * Math.sin(decl)) / (Math.cos(lat) * Math.cos(decl));
    var ha = Math.acos(Math.max(-1, Math.min(1, cosH))) / rad;
    var noon = 720 - 4 * lon - eqt;
    return [day0 + (noon - 4 * ha) * 6e4, day0 + (noon + 4 * ha) * 6e4];
  }
  window.spSunTimes = sunTimes;

  var scene = $("scene"), svg = scene && scene.querySelector("svg");
  function tick(){
    if (!scene) return;
    var now = Date.now(), d = new Date(now + MSK), s = sunTimes(now);
    $("scClock").textContent = pad(d.getUTCHours()) + ":" + pad(d.getUTCMinutes());
    scene.setAttribute("data-daypart", now < s[0] || now > s[1] ? "night" : "day");
  }
  if (scene){ tick(); setInterval(tick, 20000); }

  /* погода «сейчас» в панораме: дождь, снег, туман, гроза */
  function setWx(det){
    if (!scene || !det) return;
    scene.setAttribute("data-wx", det.kind || "");
    var box = $("sceneWx"); box.innerHTML = "";
    if (reduce) return;
    var rain = /rain|thunder|sleet/.test(det.kind), snow = /snow|sleet/.test(det.kind);
    var n = rain && snow ? 22 : rain ? 40 : snow ? 36 : 0;
    for (var i = 0; i < n; i++){
      var isSnow = snow && (!rain || i % 2), p = document.createElement("i");
      p.className = isSnow ? "snow" : "drop";
      p.style.left = (Math.random() * 104 - 2).toFixed(1) + "%";
      p.style.animationDuration = (isSnow ? 5 + Math.random() * 5 : 0.7 + Math.random() * 0.5).toFixed(2) + "s";
      p.style.animationDelay = (-Math.random() * 8).toFixed(2) + "s";
      if (isSnow){ var sz = (2.5 + Math.random() * 2.5).toFixed(1) + "px"; p.style.width = p.style.height = sz; p.style.setProperty("--dx", (Math.random() * 50 - 25).toFixed(0) + "px"); }
      box.appendChild(p);
    }
  }
  document.addEventListener("sp:wxnow", function(e){ setWx(e.detail); });
  if (window.__spWxNow) setWx(window.__spWxNow);

  /* параллакс: мышь и прокрутка */
  if (scene && fine && !reduce){
    var onMove = function(e){ scene.style.setProperty("--px", ((e.clientX / window.innerWidth) * 2 - 1).toFixed(3)); };
    document.querySelector(".hero").addEventListener("pointermove", onMove, { passive: true });
    scene.addEventListener("pointermove", onMove, { passive: true });
  }

  /* грузовик на полосе прогресса */
  var pt = $("progTruck"), topbar = $("topbar"), lastY = window.scrollY || 0, idle = 0, ticking = false, dir = 1;
  function onScroll(){
    if (ticking) return; ticking = true;
    requestAnimationFrame(function(){
      ticking = false;
      var h = document.documentElement, max = h.scrollHeight - h.clientHeight, y = window.scrollY || h.scrollTop;
      var k = max > 0 ? Math.min(1, y / max) : 0;
      if (y !== lastY) dir = y < lastY ? -1 : 1;
      var moved = y !== lastY; lastY = y;
      if (pt){
        pt.style.transform = "translateX(" + Math.max(0, k * topbar.clientWidth - 30).toFixed(1) + "px)" + (dir < 0 ? " scaleX(-1)" : "");
        if (!reduce && moved){ pt.classList.add("moving"); clearTimeout(idle); idle = setTimeout(function(){ pt.classList.remove("moving"); }, 200); }
      }
      if (scene && !reduce) scene.style.setProperty("--sy", Math.min(1, y / 700).toFixed(3));
    });
  }
  window.addEventListener("scroll", onScroll, { passive: true }); onScroll();

  /* панорама и полоса работают только на экране; SMIL-дрон тоже ставим на паузу */
  var liveEls = [scene, document.querySelector(".band")].filter(Boolean);
  function setLive(el, on){
    el.classList.toggle("inview", on);
    if (el === scene && svg && svg.pauseAnimations){ if (on && !reduce) svg.unpauseAnimations(); else svg.pauseAnimations(); }
  }
  if (hasIO){
    var lo = new IntersectionObserver(function(en){ en.forEach(function(e){ setLive(e.target, e.isIntersecting); }); }, { rootMargin: "60px 0px" });
    liveEls.forEach(function(el){ lo.observe(el); });
  } else liveEls.forEach(function(el){ setLive(el, true); });

  /* сменяющаяся техника в первом экране */
  var rot = $("rot");
  if (rot && !reduce){
    var words = ["автовышку", "автокран", "манипулятор", "экскаватор", "автогрейдер", "каток", "самосвал", "бетононасос", "ямобур", "погрузчик", "бульдозер", "трал"], wi = 0;
    var cur = rot.querySelector(".rot-w");
    setInterval(function(){
      if (document.hidden) return;
      wi = (wi + 1) % words.length;
      rot.style.width = cur.getBoundingClientRect().width + "px";
      var nw = document.createElement("span"); nw.className = "rot-w in"; nw.textContent = words[wi];
      cur.classList.remove("in"); cur.classList.add("out");
      rot.appendChild(nw);
      void rot.offsetWidth;
      rot.style.width = nw.getBoundingClientRect().width + "px";
      var old = cur; cur = nw;
      setTimeout(function(){ if (old.parentNode) old.parentNode.removeChild(old); }, 520);
    }, 2400);
  }

  /* подсветка под курсором и лёгкий 3D-наклон карточек */
  if (fine && !reduce){
    each(".card, .case, .pl-group, .doc, .step", function(el){ el.classList.add("glow"); });
    each(".card, .case", function(el){
      el.classList.add("tilt");
      el.addEventListener("pointerleave", function(){ el.style.setProperty("--rx", "0deg"); el.style.setProperty("--ry", "0deg"); });
    });
    document.addEventListener("pointermove", function(e){
      var el = e.target.closest && e.target.closest(".glow"); if (!el) return;
      var r = el.getBoundingClientRect(), x = e.clientX - r.left, y = e.clientY - r.top;
      el.style.setProperty("--mx", x.toFixed(0) + "px"); el.style.setProperty("--my", y.toFixed(0) + "px");
      if (el.classList.contains("tilt")){
        el.style.setProperty("--ry", ((x / r.width - 0.5) * 7).toFixed(2) + "deg");
        el.style.setProperty("--rx", ((0.5 - y / r.height) * 6).toFixed(2) + "deg");
      }
    }, { passive: true });
  }

  /* волна при нажатии */
  if (!reduce) document.addEventListener("pointerdown", function(e){
    var b = e.target.closest && e.target.closest(".btn, .opt, .pl-add, .presets button, .wx-day"); if (!b) return;
    var r = b.getBoundingClientRect(), s = Math.max(r.width, r.height) * 2.2, sp = document.createElement("span");
    sp.className = "rip"; sp.setAttribute("aria-hidden", "true");
    sp.style.width = sp.style.height = s.toFixed(0) + "px";
    sp.style.left = (e.clientX - r.left - s / 2).toFixed(0) + "px"; sp.style.top = (e.clientY - r.top - s / 2).toFixed(0) + "px";
    b.appendChild(sp); setTimeout(function(){ if (sp.parentNode) sp.parentNode.removeChild(sp); }, 650);
  }, { passive: true });

  /* черта под заголовками и линия шагов */
  var steps = document.querySelector(".steps");
  if (steps){
    each(".steps .step", function(el, i){ el.style.setProperty("--i", i); });
    var tr = document.createElement("span"); tr.className = "steps-truck"; tr.setAttribute("aria-hidden", "true");
    tr.innerHTML = $("progTruck").innerHTML; steps.appendChild(tr);
  }
  var drawEls = document.querySelectorAll(".section-head h2, .geo h2, .docs h2, .steps");
  if (reduce || !hasIO) Array.prototype.forEach.call(drawEls, function(el){ el.classList.add("drawn"); });
  else {
    var dO = new IntersectionObserver(function(en){ en.forEach(function(e){ if (e.isIntersecting){ e.target.classList.add("drawn"); dO.unobserve(e.target); } }); }, { threshold: 0.5, rootMargin: "0px 0px -40px 0px" });
    Array.prototype.forEach.call(drawEls, function(el){ dO.observe(el); });
  }

  /* вопросы: плавное раскрытие */
  each(".faq details", function(d){
    var s = d.querySelector("summary"), p = d.querySelector("p");
    s.addEventListener("click", function(e){
      if (reduce || !d.animate) return;
      e.preventDefault();
      if (d._a){ d._a.cancel(); d._a = null; }
      var cs = getComputedStyle(d), start = d.getBoundingClientRect().height;
      d.style.overflow = "hidden";
      if (!d.open){
        d.open = true;
        var end = d.getBoundingClientRect().height;
        d._a = d.animate({ height: [start + "px", end + "px"] }, { duration: 340, easing: "cubic-bezier(.2,.7,.2,1)" });
        if (p && p.animate) p.animate({ opacity: [0, 1], transform: ["translateY(-6px)", "none"] }, { duration: 340, easing: "ease-out" });
        d._a.onfinish = function(){ d._a = null; d.style.overflow = ""; };
      } else {
        var closed = s.getBoundingClientRect().height + parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom) + parseFloat(cs.borderTopWidth) + parseFloat(cs.borderBottomWidth);
        var a = d._a = d.animate({ height: [start + "px", closed + "px"] }, { duration: 280, easing: "cubic-bezier(.4,0,.2,1)", fill: "forwards" });
        a.onfinish = function(){ d.open = false; a.cancel(); d._a = null; d.style.overflow = ""; };
      }
    });
  });
})();
</script>
