const { chromium } = require('playwright');
const fs = require('fs');
const real = fs.readFileSync('real_met.json','utf8');
(async () => {
  const b = await chromium.launch(); const errs = [];
  async function open(url, opts={}){
    const p = await b.newPage(Object.assign({viewport:{width:1280,height:900}}, opts));
    p.on('pageerror', e => errs.push(url+': '+e.message));
    p.goals = [];
    await p.route('https://api.met.no/**', r => r.fulfill({status:200, contentType:'application/json', headers:{'access-control-allow-origin':'*'}, body: real}));
    await p.route('https://mc.yandex.ru/**', r => r.fulfill({status:200, contentType:'application/javascript', body: 'window.__ymq = (window.ym && window.ym.a) || []; window.ym = function(){ window.__ymq.push(Array.from(arguments)); };'}));
    await p.goto(url); await p.waitForTimeout(1200); return p;
  }
  // 1. production file, no metrika
  const a = await open('http://127.0.0.1:8765/');
  console.log('A cookie hidden:', await a.$eval('#cookie', e=>e.hidden), '| ym defined:', await a.evaluate(()=>typeof window.ym), '| footer:', (await a.textContent('footer')).replace(/\s+/g,' ').trim());
  console.log('A wx:', (await a.textContent('#wxOrder')).replace(/\s+/g,' ').slice(0,120));
  const fav = await a.evaluate(async()=> (await fetch('favicon.svg')).status + ' ' + (await fetch('privacy.html')).status + ' ' + (await fetch('robots.txt')).status + ' ' + (await fetch('sitemap.xml')).status);
  console.log('A assets:', fav);
  // 2. metrika on
  const m = await open('http://127.0.0.1:8765/_mtest.html');
  console.log('M cookie hidden:', await m.$eval('#cookie', e=>e.hidden));
  await m.click('#cookieOk'); console.log('M cookie after ok:', await m.$eval('#cookie', e=>e.hidden));
  await m.evaluate(()=>{ document.querySelector('a[href^="tel:"]').addEventListener('click', e=>e.preventDefault(), {once:true}); });
  await m.click('.top-phone a.num').catch(()=>{});
  await m.click('[data-add="grader"]');
  await m.click('#copyBtn').catch(()=>{});
  await m.click('#kpBtn');
  await m.click('.wx-day:nth-child(2)');
  await m.evaluate(()=>{ const a=document.getElementById('waLink'); a.addEventListener('click', e=>e.preventDefault(), {once:true}); a.click(); });
  const q = await m.evaluate(()=> (window.__ymq || (window.ym && window.ym.a) || []).map(x=>Array.from(x).slice(1).map(v=>typeof v==='object'?JSON.stringify(v):v).join(':')));
  console.log('M ym calls:', q);
  const m2 = await open('http://127.0.0.1:8765/_mtest.html');
  console.log('M reload cookie hidden (remembered):', await m2.$eval('#cookie', e=>e.hidden));
  // 3. privacy
  for (const [n,w,s] of [['pl',1280,'light'],['pm',390,'dark']]){
    const p = await b.newPage({viewport:{width:w,height:900}, colorScheme:s}); p.on('pageerror', e=>errs.push('privacy '+e.message));
    await p.goto('http://127.0.0.1:8765/privacy.html'); await p.waitForTimeout(300);
    await p.screenshot({path:'priv_'+n+'.png', fullPage:true});
    console.log('privacy', n, 'sw', await p.evaluate(()=>document.documentElement.scrollWidth));
  }
  const mob = await open('http://127.0.0.1:8765/_mtest.html', {viewport:{width:390,height:844}});
  await mob.screenshot({path:'cookie_mob.png'});
  console.log('errors:', errs);
  await b.close();
})();
